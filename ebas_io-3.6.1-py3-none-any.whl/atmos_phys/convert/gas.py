"""
$Id: gas.py 2660 2021-06-02 10:00:04Z pe $

atmos_phys unit conversion routines for gasses.
"""

from nilutility import numeric
from nilutility.datatypes import DataObject
from .base import ConvertBaseFactor
from .elements import ELEMENTS

R = 8.3144621  # Gas constant

MIXING_TO_MASSCONC = 1
MASSCONC_TO_MIXING = 2

class ConvertGasBase(ConvertBaseFactor):  # pylint: disable=W0223
    # W0223: Method ... is abstract in base class but is not overridden
    """
    Base class for gas conversions (mixing ratio / mass concentration).
    """

    def __init__(self, from_unit, to_unit, roundoffset=0, maxround=None,
                 temperature=273.15, pressure=101325):
        # pylint: disable=R0913
        # R0913: Too many arguments
        """
        Set up conversion object.
        Parameters:
            from_unit
            to_unit      conversion from and to unit. Must be checked in
                         _set_parameters of the final class.
            roundoffset  rounding offset (usually +1 for import and -1 for
                         export)
            maxround     maximum rounding threshold, do no round coarser then
                         this should be used for export conversion only
                         (rounding expressed like in round function, 0=integer,
                         1=1digit after comma)
            temperature  temperature (standard conditions)
            pressure     pressure (standard conditions)
        For gas conversions, temperature and pressure (standard conditions for
        mass concentrations) are additionally needed.
        """
        # additional attributes for standard conditions.
        self.temperature = temperature
        self.pressure = pressure
        # call base class init
        super(ConvertGasBase, self).__init__(from_unit, to_unit, roundoffset,
                                             maxround)

    def conversion_string(self, from_val=None, to_val=None):
        """
        Generates a conversion parameter string for the conversion.
        E.g. "from nmol/mol to ug/m3 273.15 K, 1013.25 hPa, using factor 1.234",
             "from nmol/mol to ug/m3 at 273.15 K, 1013.25 hPa, no conversion "
                 "factor used (no nonzero, valid values)"
        Parameters:
            from_val
            to_val
               If from_val and to_val are given, the values are included in the
               string (used to document conversion of uncertainty or detection
               limit values).
        Returns a string for documenting the conversion.
        """
        from_val = "{} ".format(from_val) if from_val is not None else ""
        to_val = "{} ".format(to_val) if to_val is not None else ""
        if self.rounding is None:
            convf = "no conversion factor (no nonzero, valid values)"
        else:
            convf = "conversion factor {:.{rdigits}f}"\
                    .format(self.parameters.factor, rdigits=self.rounding+2)

        if self.parameters.mixingratio_to_massconc:
            return ("from '{}{}' to '{}{}' at {} K, {} hPa, {}").format(
                from_val, self.from_unit, to_val, self.to_unit,
                self.temperature, self.pressure/100.0, convf)
        return ("from '{}{}' at {} K, {} hPa to '{}{}', {}").format(
            from_val, self.from_unit, self.temperature, self.pressure/100.0,
            to_val, self.to_unit, convf)


class ConvertNOx(ConvertGasBase):
    """
    Conversion class for NOx (NO, NO2, NOx) conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug N/m3', 'nmol/mol', 'ppbv', 'ppb') or \
           self.to_unit not in ('ug N/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug N/m3':
            self.parameters.factor = ELEMENTS['N']['MolarMass']/1000.0 / \
                (R*self.temperature/self.pressure)
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = (R*self.temperature/self.pressure) / \
                (ELEMENTS['N']['MolarMass'] / 1000.0)
            self.parameters.mixingratio_to_massconc = False


class ConvertSulphurDioxide(ConvertGasBase):
    """
    Conversion class for NOx (NO, NO2, NOx) conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug S/m3', 'nmol/mol', 'ppbv', 'ppb') or \
           self.to_unit not in ('ug S/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug S/m3':
            self.parameters.factor = ELEMENTS['S']['MolarMass']/1000.0 / \
                (R*self.temperature/self.pressure)
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = (R*self.temperature/self.pressure) / \
                (ELEMENTS['S']['MolarMass'] / 1000.0)
            self.parameters.mixingratio_to_massconc = False


class ConvertOzone(ConvertGasBase):
    """
    Conversion class for ozone conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = 3*ELEMENTS['O']['MolarMass']/1000.0 / \
                (R*self.temperature/self.pressure)
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = (R*self.temperature/self.pressure) / \
                (3*ELEMENTS['O']['MolarMass']/1000.0)
            self.parameters.mixingratio_to_massconc = False


class ConvertEthanal(ConvertGasBase):
    """
    Conversion class for ethanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        # ethanal is C2H4O
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (2 * ELEMENTS['C']['MolarMass'] +
                 4 * ELEMENTS['H']['MolarMass'] +
                 ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((2 * ELEMENTS['C']['MolarMass'] +
                  4 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class ConvertEthanol(ConvertGasBase):
    """
    Conversion class for ethanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        # ethanol is C2H6O
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (2 * ELEMENTS['C']['MolarMass'] +
                 6 * ELEMENTS['H']['MolarMass'] +
                 ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((2 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class ConvertMethanal(ConvertGasBase):
    """
    Conversion class for methanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (1 * ELEMENTS['C']['MolarMass'] +
                 2 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((1 * ELEMENTS['C']['MolarMass'] +
                  2 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class ConvertPropanone(ConvertGasBase):
    """
    Conversion class for propanone conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (3 * ELEMENTS['C']['MolarMass'] +
                 6 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((3 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class ConvertPropanal(ConvertGasBase):
    """
    Conversion class for propanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (3 * ELEMENTS['C']['MolarMass'] +
                 6 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((3 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class ConvertNPropanol(ConvertGasBase):
    """
    Conversion class for n-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        # n-propanol is C3H8O
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (3 * ELEMENTS['C']['MolarMass'] +
                 8 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((3 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class Convert2Methyl2Propenal(ConvertGasBase):
    """
    Conversion class for methacrolein conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (4 * ELEMENTS['C']['MolarMass'] +
                 6 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((4 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class ConvertEthanedial(ConvertGasBase):
    """
    Conversion class for glyoxal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (2 * ELEMENTS['C']['MolarMass'] +
                 2 * ELEMENTS['H']['MolarMass'] +
                 2 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((2 * ELEMENTS['C']['MolarMass'] +
                  2 * ELEMENTS['H']['MolarMass'] +
                  2 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False

class Convert2Oxopropanal(ConvertGasBase):
    """
    Conversion class for methylglyoxal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'nmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (3 * ELEMENTS['C']['MolarMass'] +
                 4 * ELEMENTS['H']['MolarMass'] +
                 2 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((3 * ELEMENTS['C']['MolarMass'] +
                  4 * ELEMENTS['H']['MolarMass'] +
                  2 * ELEMENTS['O']['MolarMass']) / 1000.0)
            self.parameters.mixingratio_to_massconc = False


class Convert2Propenal(ConvertGasBase):
    """
    Conversion class for 2-propenal conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'pmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (3 * ELEMENTS['C']['MolarMass'] +
                 4 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((3 * ELEMENTS['C']['MolarMass'] +
                  4 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            # to_unit == pmol/mol:
            self.parameters.factor *= 1000.0
            self.parameters.mixingratio_to_massconc = False

class Convert3Buten2One(ConvertGasBase):
    """
    Conversion class for 3-buten-2-one conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'pmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (4 * ELEMENTS['C']['MolarMass'] +
                 6 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((4 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            # to_unit == pmol/mol:
            self.parameters.factor *= 1000.0
            self.parameters.mixingratio_to_massconc = False

class ConvertButanone(ConvertGasBase):
    """
    Conversion class for butanone conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        if self.from_unit not in ('ug/m3', 'nmol/mol', 'ppbv', 'ppb',
                                  'pmol/mol', 'pptv', 'ppt') or \
           self.to_unit not in ('ug/m3', 'pmol/mol') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(factor=None)
        if self.to_unit == 'ug/m3':
            self.parameters.factor = \
                (4 * ELEMENTS['C']['MolarMass'] +
                 8 * ELEMENTS['H']['MolarMass'] +
                 1 * ELEMENTS['O']['MolarMass']) / 1000.0 / \
                (R*self.temperature/self.pressure)
            if self.from_unit in ('pmol/mol', 'pptv', 'ppt'):
                self.parameters.factor /= 1000.0
            self.parameters.mixingratio_to_massconc = True
        else:
            self.parameters.factor = \
                (R*self.temperature/self.pressure) / \
                ((4 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass']) / 1000.0)
            # to_unit == pmol/mol:
            self.parameters.factor *= 1000.0
            self.parameters.mixingratio_to_massconc = False


def convf_volume_standard(temp1=273.15, pres1=101325, temp2=273.15,
                          pres2=101325):
    """
    Conversion factor for converting concentrations from one condition to
    another.
    Parameters:
        temp1, pres2    temperature and pressure to convert from
        temp2, pres2    temperature and pressure to convert to

        all temperatures in K, all pressures in Pa (not hPa!!!)
    Returns:
        conversion factor
    """
    return (temp1 * pres2) / (temp2 * pres1)
