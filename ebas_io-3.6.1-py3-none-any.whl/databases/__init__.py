"""
Module databases

helpers and middle layers for accessing diverse databases
"""

__version__ = 'V.1.02.01'
