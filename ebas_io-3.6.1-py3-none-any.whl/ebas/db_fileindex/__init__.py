"""
ebas/db_fileindex
$Id: __init__.py 2244 2019-03-01 14:13:34Z pe $

Database I/O for EBAS fileindex database (sqlite3)

This module provides the class IndexDb

History:
V.1.0.0  2015-04-02  pe  initial version

"""

# expose main class to users
from sqlite3 import OperationalError
from .indexdb import IndexDb
from .indexdb_internal import IndexDbInternal
