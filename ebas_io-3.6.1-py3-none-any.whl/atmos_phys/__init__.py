"""
$Id: __init__.py 2677 2021-06-28 19:34:09Z pe $

moule Atmoshys

History:
V.1.0.0  2015-03-09  pe  initial version

"""

__version__ = 'V.1.08.00'
