"""
$Id: __init__.py 844 2015-03-10 11:43:19Z pe $

moule Atmoshys.convert

History:
V.1.0.0  2015-03-09  pe  initial version

"""
