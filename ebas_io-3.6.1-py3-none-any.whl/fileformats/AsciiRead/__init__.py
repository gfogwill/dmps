"""
Basic file IO for ASCII datafiles. Mainly encoding and special character issues.
"""

from fileformats.AsciiRead.ascii_read import AsciiRead, \
    AsciiReadError, BackposError
