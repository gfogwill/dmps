"""
ebas/domain/masterdata/co.py
$Id: co.py 2660 2021-06-02 10:00:04Z pe $

EBAS Masterdata Class for component masterdata

This module implements the class EbasMasterCO.

History:
V.1.0.0  2014-02-25  pe  initial version

"""

from .offline_masterdata import COOfflineMasterData
from .base import EbasMasterBase

class EbasMasterCO(EbasMasterBase, COOfflineMasterData):
    """
    Domain Class for components masterdata.
    Objects of this class do not represent entities, this class provides class
    methods for handling components and checking them against master data.
    Components master data are retrieved from database or from offline storage
    when no database access is possible.
    """

    # read offline masterdata for CO (components)
    # Those are fallback values, will be read from database as soon as possible.
    COOfflineMasterData.read_pickle_file()
    # some hardcoded exceptional components (see method exceptional):
    CO_EXCEPTIONAL = {
        "0": {
            # ACSM lev0:
            'collection_efficiency': {
                'CO_COMP_NAME': 'collection_efficiency',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            'nitrogen_ion_flow_signal': {
                'CO_COMP_NAME': 'nitrogen_ion_flow_signal',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            'relative_ionization_efficiency': {
                'CO_COMP_NAME': 'relative_ionization_efficiency',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            'airbeam_signal': {
                'CO_COMP_NAME': 'airbeam_signal',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            'frequency': {
                'CO_COMP_NAME': 'frequency',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            'electric_power': {
                'CO_COMP_NAME': 'electric_power',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            'ionization_efficiency': {
                'CO_COMP_NAME': 'ionization_efficiency',
                'CO_CAPTION': None,
                'CO_DESC': None,
            },
            # NOX lev 0:
            'NO_#counts': {
                'CO_COMP_NAME': 'NO_#counts',
                'CO_CAPTION': 'NO_count',
                'CO_DESC': None,
            },
            'NO_converter_#counts':{
                'CO_COMP_NAME': 'NO_converter_#counts',
                'CO_CAPTION': 'NOc_count',
                'CO_DESC': None,
            },
            'NO_sensitivity':{
                'CO_COMP_NAME': 'NO_sensitivity',
                'CO_CAPTION': 'NO_sens',
                'CO_DESC': None,
            },
            'converter_efficiency':{
                'CO_COMP_NAME': 'converter_efficiency',
                'CO_CAPTION': 'converter_eff',
                'CO_DESC': None,
            },

            # dmps lev 0:
            'particle_diameter': {
                'CO_COMP_NAME': 'particle_diameter',
                'CO_CAPTION': 'p_diam',
                'CO_DESC': None,
            },
            # filter_absorption_photometer lev 0:
            'equivalent_black_carbon_loading': {
                'CO_COMP_NAME': 'equivalent_black_carbon_loading',
                'CO_CAPTION': 'BCmass',
                'CO_DESC': None,
            },
            # filter_absorption_photometer lev 0 (clap):
            'sample_length_on_filter': {
                'CO_COMP_NAME': 'sample_length_on_filter',
                'CO_CAPTION': 'smpllen',
                'CO_DESC': None,
            },
            # filter_absorption_photometer lev 0 (AE33):
            'filter_number': {
                'CO_COMP_NAME': 'filter_number',
                'CO_CAPTION': 'tpcnt',
                'CO_DESC': None,
            },
            # filter_absorption_photometer lev 0 (AE33):
            'biomass_burning_aerosol_fraction': {
                'CO_COMP_NAME': 'biomass_burning_aerosol_fraction',
                'CO_CAPTION': 'BB',
                'CO_DESC': None,
            },
            # filter_absorption_photometer lev 0 (AE33):
            'filter_loading_compensation_parameter': {
                'CO_COMP_NAME': 'filter_loading_compensation_parameter',
                'CO_CAPTION': 'k',
                'CO_DESC': None,
            },
            # nephelometer lev0
            'aerosol_light_scattering_coefficient_zero_measurement': {
                'CO_COMP_NAME':
                    'aerosol_light_scattering_coefficient_zero_measurement',
                'CO_CAPTION': 'scat0',
                'CO_DESC': None,
            },
            'aerosol_light_backscattering_coefficient_zero_measurement': {
                'CO_COMP_NAME':
                    'aerosol_light_backscattering_coefficient_zero_measurement',
                'CO_CAPTION': 'bscat0',
                'CO_DESC': None,
            },
            'aerosol_light_rayleighscattering_coefficient_zero_measurement': {
                'CO_COMP_NAME':
                    'aerosol_light_rayleighscattering_coefficient_'
                    'zero_measurement',
                'CO_CAPTION': 'rscat0',
                'CO_DESC': None,
            },
            # CCNC, DMPS-CCNC lev0:
            'supersaturation': {
                'CO_COMP_NAME': 'supersaturation',
                'CO_CAPTION': 'SS',
                'CO_DESC': None,
            },
            'temperature_gradient': {
                'CO_COMP_NAME': 'temperature_gradient',
                'CO_CAPTION': 'dT',
                'CO_DESC': None,
            },
            # cpc lev0:
            'pulse_width': {
                'CO_COMP_NAME': 'pulse_width',
                'CO_CAPTION': 'pulse',
                'CO_DESC': None,
            },

        },
        "1": {
            # CCNC, DMPS-CCNC lev1:
            'supersaturation': {
                'CO_COMP_NAME': 'supersaturation',
                'CO_CAPTION': 'SS',
                'CO_DESC': None,
            },
        },
    }

    def __init__(self, dbh=None):
        """
        Read co masterdata if dbh is provided.
        """
        COOfflineMasterData.__init__(self)
        if not self.__class__.INIT and dbh:
            self.from_db(dbh)


    def exceptional(self, data_level, name):
        """
        Find exceptional components (depend on data_level).
        Those components are NOT defined in the database, but might be e.g. used
        in lev 0 files.
        Thus they are accepted when reading the file, but the domain layer will
        issue an error message.
        """
        if data_level in ['0a', '0b']:
            data_level = '0'
        return self.__class__.CO_EXCEPTIONAL[data_level][name]
