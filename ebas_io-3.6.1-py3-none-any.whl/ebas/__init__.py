"""
Module nilu.ebas:
EBAS specific modules, currently:
db:     ebas database access
entity: ebas entity object classes
"""
__version__ = 'V.3.06.01'
