"""
ebas/domain/
$Id: __init__.py 1345 2016-07-20 16:55:38Z pe $

EBAS domain layer (entity objects and domain logic)

History:
V.1.0.0  2012-05-21  pe  initial version

"""

from .base import EbasDomainError, EbasDomainDbContext
