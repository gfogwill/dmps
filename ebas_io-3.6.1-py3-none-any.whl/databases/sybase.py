"""
$Id: sybase.py 2599 2021-01-27 16:27:04Z pe $
basic module for accessing sybase databases
"""
import uuid
from textwrap import dedent
import logging
import six
import Sybase
from nilutility.datatypes import DataObject
from .base import DbBase
# from sybasect import CS_FLOAT_TYPE
# works nicely, but error in pylint, as sybasect is loaded from dynamic
CS_FLOAT_TYPE = __import__('sybasect', globals(), locals(), ['CS_FLOAT_TYPE'],
                           -1).CS_FLOAT_TYPE

# Exceptions
class SybaseDbBaseError(Exception):
    """Base class for exceptions."""
    def __init__(self, msg):
        Exception.__init__(self, msg)
        self.msg = msg
    def __str__(self):
        return self.msg
class DbError(SybaseDbBaseError):
    """Exception used for database errors."""
    def __init__(self, msg, svrmsg=None):
        SybaseDbBaseError.__init__(self, msg)
        if svrmsg:
            self.svrmsg = svrmsg


class SybaseDbBase(DbBase):  # pylint: disable=R0903
    # R0903: Too few public methods
    # This is a base class...
    """
    Base class for database access in Sybase.

    Instance attributes:
        conn      db connection object
        cursor_fetch_buffer
                  buffer size for fetch operations
        logger    logging object
    """

    # Used by base class
    DB_MAXLEN_IDENTIFIER = 30

    def __init__(self):
        """
        Constructor for class SybaseDbBase.
        """
        self._dbuser = None
        Sybase.CS_MAX_CHAR = 256
        self.cursor_fetch_buffer = 1000
        self.logger = logging.getLogger('SybaseDbBase')
        self.conn = None  # do not connect on base class instantiation
        self.tmp_addsql_crit_tables = []

    def _connect(  # pylint: disable=R0913
            # R0913: Too many arguments
            # --> Alternatives in this case? dict? list?
            # Would make things even more opaque...
            self, dbhost, dbuser, dbpasswd, dbname,
            auto_commit=False, bulkcopy=False):
        """
        Creates a new connection, only used internally.
        Parameters:
            dbhost    connection name from /etc/freetds.conf
            dbuser    user to connect with
            dbpasswd
            dbname
        Returns:
            connection handle
        """
        self.logger.debug('connecting: dbhost: %s{0}, dbuser: %s, dbname:%s',
                          dbhost, dbuser, dbname)
        try:
            return Sybase.connect(dbhost, dbuser, dbpasswd, dbname,
                                  locale='utf8',
                                  outputmap=Sybase.DateTimeAsPython,
                                  auto_commit=1 if auto_commit else 0,
                                  bulkcopy=1 if bulkcopy else 0)
        except Sybase.Error as expt:
            self.logger.critical(
                'DB connect error (conn_ts): dbhost=%s, dbuser=%s, dbname=%s: '
                '%s', dbhost, dbuser, dbname, str(expt))
            raise DbError(
                'DB connect error  (conn_ts): dbhost={0}, dbuser={1}, '
                'dbname={2}: {3}'.format(dbhost, dbuser, dbname, str(expt)))

    def _execute(self, sql, params={}, select=None):
        # pylint: disable=W0102
        #  W0102: Dangerous default value {} (same as original method)
        """
        Perform a DB execute on a new cursor, additionally add error logging and
        exception handling.

        This is a private method.
        Some derived classes (e.g. ebas.db) do not want to expose methods like
        execute or executemany as public.

        Parameters:
            sql    }
            params } parameters are just handed through to curs.execute
            select }
        Returns:
            new cursor object
        """
        self.logger.debug("SybaseDb.execute: %s", sql)
        if params:
            for key in params:
                if isinstance(params[key], six.text_type):
                    params[key] = params[key].encode('utf-8')
            self.logger.debug(
                "SybaseDb.execute - PARAMS:\n %s",
                '\n '.join(['{0}: {1} ({2})'.format(key, value, type(value))
                            for (key, value) in list(params.items())]))
        else:
            self.logger.debug("SybaseDb.execute - PARAMS: None")
        curs = self.conn.cursor()
        try:
            curs.execute(sql, params, select)
        except Sybase.DatabaseError as expt:
            curs = None
            self.logger.critical('DB error: %s\n%s', str(expt), sql)
            # self.rollback()  -- this should be decided by caller
            raise DbError('{0}\n{1}'.format(str(expt), sql), svrmsg=expt.msg)
        return curs

    def _executemany(self, sql, params):
        """
        Perform a DB executemany on a new cursor, additionally add error logging
        and exception handling.

        This is a private method.
        Some derived classes (e.g. ebas.db) do not want to expose methods like
        execute or executemany as public.

        Parameters:
            sql    }
            params } parameters are just handed through to curs.executemany
        Returns:
            new cursor object
        """
        self.logger.debug("SybaseDb.executemany: %s", sql)
        self.logger.debug("SybaseDb.execute - PARAMS: " + \
            '\n '+'\n '.join([str(row) for row in params]))
        # create a savepoint - roll back to this state if something goes wrong!
        self.conn.execute('save transaction executemany')
        curs = self.conn.cursor()
        try:
            curs.executemany(sql, params)
        except Sybase.DatabaseError as expt:
            self.logger.critical('DB error: %s\n%s', str(expt), sql)
            self.conn.rollback(name='executemany')
            raise DbError('{0}\n{1}'.format(str(expt), sql), svrmsg=expt.msg)
        except:
            self.conn.rollback(name='executemany')
            raise
        return curs

    def _yield_dict(self, curs):
        """
        Yields the cursur results as dictionary per row.

        Parameters:
            curs    opened cursor object
        Returns:
            generator, dictionaries with results, None if no result
        """
        while True:
            results = curs.fetchmany(self.cursor_fetch_buffer)
            if not results:
                curs.close()
                break
            for result in results:
                yield self._convert_row2dict(result, curs.description)

    @staticmethod
    def _cvt_float(val):
        """
        Convert to float if not None.

        Parameters:
            val    value to be converted
        Returns:
            float(val) or None
        """
        if val != None:
            return float(val)
        return None

    @staticmethod
    def _cvt_int(val):
        """
        Convert to int if not None.

        Parameters:
            val    value to be converted
        Returns:
            int(val) or None
        """
        if val != None:
            return int(val)
        return None

    @staticmethod
    def _cvt_str(val):
        """
        Convert to unicode if not None.

        Parameters:
            val    value to be converted
        Returns:
            decoded unicode string (from utf-8 encoding as returned by the
            database)
        """
        if val != None:
            return val.decode('utf-8')
        return None

    @staticmethod
    def _convert_row2dict(result, desc):
        """
        Converts a fetched row (tupel) to a dictionary (keys=colnames). Performs
        all needed conversions (char, float etc).

        Parameters:
            result    fetched result row (tupel)
            desc      cursor description
        """
        ret = DataObject()
        for i, val in enumerate(result):
            colnam = desc[i][0]
            if Sybase.STRING.__cmp__(desc[i][1]) == 0:
                ret[colnam] = SybaseDbBase._cvt_str(val)
            elif Sybase.NUMBER.__cmp__(desc[i][1]) == 0:
                # pylint: disable=E1101
                #  E1101: Module 'sybasect' has no 'CS_FLOAT_TYPE' member
                #         (??? unknown reason for this error, code works)
                if desc[i][5] > 0 or desc[i][1] == CS_FLOAT_TYPE:
                    # scale > 0 or float
                    ret[colnam] = SybaseDbBase._cvt_float(val)
                else:
                    ret[colnam] = SybaseDbBase._cvt_int(val)
            elif Sybase.DATETIME.__cmp__(desc[i][1]) == 0:
                # conversion already done by outputmap=Sybase.DateTimeAsPython
                ret[colnam] = val
            elif Sybase.BINARY.__cmp__(desc[i][1]) == 0:
                raise NotImplementedError("binary columns not implemented")
            else:
                raise NotImplementedError("data type code not implemented")
        return ret

    @staticmethod
    def _convert_row2list(result, desc):
        """
        Converts a fetched row (tupel) to a list (same order). Performes
        all needed conversions (char, float etc).

        Parameters:
            result    fetched result row (tupel)
            desc      cursor description
        """
        ret = []
        for i, val in enumerate(result):
            if Sybase.STRING.__cmp__(desc[i][1]) == 0:
                ret.append(SybaseDbBase._cvt_str(val))
            elif Sybase.NUMBER.__cmp__(desc[i][1]) == 0:
                # pylint: disable=E1101
                #  E1101: Module 'sybasect' has no 'CS_FLOAT_TYPE' member
                #         (??? unknown reason for this error, code works)
                if desc[i][5] > 0 or desc[i][1] == CS_FLOAT_TYPE:
                    # scale > 0 or float
                    ret.append(SybaseDbBase._cvt_float(val))
                else:
                    ret.append(SybaseDbBase._cvt_int(val))
            elif Sybase.DATETIME.__cmp__(desc[i][1]) == 0:
                # conversion already done by outputmap=Sybase.DateTimeAsPython
                ret.append(val)
            elif Sybase.BINARY.__cmp__(desc[i][1]) == 0:
                raise NotImplementedError("binary columns not implemented")
            else:
                raise NotImplementedError("data type code not implemented")
        return ret

    @staticmethod
    def _hostvar_sql(varname):
        """
        Returns the sql part of a host variable name.
        """
        return "@{}".format(varname)

    @staticmethod
    def _hostvar_param(varname):
        """
        Returns the parameter dictionary key for a host variable.
        """
        return "@{}".format(varname)

    def _insert_addsql_crit(self, in_list):
        """
        Insert table entries for addsql_crit.
        Parameters:
            in_list    list of criteria values
        Returns:
            temp_id    id for the values in the temp table
        """
        if any([isinstance(elem[1], six.string_types) for elem in in_list]):
            valtype = 'VAL_CHR'
        elif any([isinstance(elem[1], float) for elem in in_list]):
            valtype = 'VAL_DBL'
        else:
            valtype = 'VAL_INT'
        temp_sql = dedent("""\
             insert into TMP_ADDSQL_CRIT (ID, TIME, {})
                 values (@ID, GetUTCDate(), @VAL)""".format(valtype))
        temp_id = uuid.uuid1().hex
        self.tmp_addsql_crit_tables.append(temp_id)
        temp_params = {'@ID': temp_id}
        for elem in in_list:
            temp_params['@VAL'] = elem[1]
            self._execute(temp_sql, temp_params)
        return "select {} from TMP_ADDSQL_CRIT where ID='{}'".format(
            valtype, temp_id)

    def _cleanup_addsql_crit(self):
        """
        Cleanup temp table entries from addsql_crit
        Parameters:
            None
        Returns:
            None
        """
        sql = "delete from TMP_ADDSQL_CRIT where ID=@ID"
        params = {}
        for id_ in self.tmp_addsql_crit_tables:
            params['@ID'] = id_
            self._execute(sql, params)
        self.tmp_addsql_crit_tables = []

    def commit(self):
        """
        Commits the current transaction.

        Parameters:
            transcomment   transaction comment to be logged in the transaction
                           table
        Returns:
            None

        See also doc for EbasDbBase.__init__ regarding auto_commit=0
        """
        # Make sure the temporary entries in TMP_ADDSQL_CRIT are never committed
        self._cleanup_addsql_crit()  # just in case...
        self.conn.commit()

class SybaseDb(SybaseDbBase):
    """
    Final class for database access in Sybase. Using mainly the execute method
    (client needs to formulate the sql).
    See e.g. ebas/db for amore advanced final implementation.

    Instance attributes:
        conn      db connection object
        cursor_fetch_buffer
                  buffer size for fetch operations
        logger    logging object
    """

    def __init__(  # pylint: disable=R0913
            # R0913: Too many arguments
            # --> Alternatives in this case? dict? list?
            # Would make things even more opaque...
            self, dbhost, dbuser, dbpasswd, dbname,
            auto_commit=False, bulkcopy=False):
        """
        Constructor for class SybaseDbBase.

        Connects to the database.
        We use the deafult auto_commit=0, which turns transaction chaining
        automatically on.
        From the Sybase manual:
          If you set chained transaction mode, Adaptive Server implicitly
          invokes a begin transaction before the following statements:
          delete, insert, open, fetch, select, and update.
          You must still explicitly close the transaction with a commit.

        Parameters:
            dbhost    connection name from /etc/freetds.conf
            dbuser    user to connect with
            dbpasswd
            dbname
        """
        super(SybaseDb, self).__init__()
        self.logger = logging.getLogger('SybaseDb')
        self.conn = self._connect(
            dbhost, dbuser, dbpasswd, dbname, auto_commit, bulkcopy)
        self._dbuser = dbuser

    def execute(self, sql, params={}, select=None):
        # pylint: disable=W0102
        #  W0102: Dangerous default value {} (same as original method)
        """
        Perform a DB execute on a new cursor, additionally add error logging and
        exception handling.

        This is just a wrapper arount the base classes private _execute method.
        Necessary, because some derived classes (e.g. ebas.db) do not want to
        expose methods like execute or executemany as public.

        Parameters:
            sql    }
            params } parameters are just handed through to curs.execute
            select }
        Returns:
            new cursor object
        """
        return self._execute(sql, params=params, select=select)

    def executemany(self, sql, params):
        """
        Perform a DB executemany on a new cursor, additionally add error logging
        and exception handling.

        This is just a wrapper arount the base classes private _execute method.
        Necessary, because some derived classes (e.g. ebas.db) do not want to
        expose methods like execute or executemany as public.

        Parameters:
            sql    }
            params } parameters are just handed through to curs.executemany
        Returns:
            new cursor object
        """
        return self._executemany(sql, params)

    def rollback(self):
        """
        Rolls the current transaction back.

        Parameters:
            None
        Returns:
            None

        See also doc for EbasDbBase.__init__ regarding auto_commit=0
        """
        self.conn.rollback()

    def close(self):
        """
        Closes all DB connections.
        Exceptiuons while rolling back/closing are ignored until all connections
        are closed, then the last exception (if any) is raised. That means, even
        if one connection fails to close, all others will be tried to close.

        Parameters:
            None
        Returns:
            None
        """
        # pylint: disable=W0703
        # W0703: Catching too general exception Exception
        # --> we want to catch all exceptions
        expt = None
        try:
            self.rollback()
        except Exception as expt:
            pass
        try:
            self.conn.close()
        except Exception as expt:
            pass
        self.conn = None
        if expt is not None:
            # pylint: disable=E0702
            # E0702: Raising NoneType
            # --> pylint problem, we are not raising NoneType
            raise expt

