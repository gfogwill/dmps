"""
ebas/domain/masterdata/pm.py
$Id: pm.py 2669 2021-06-28 15:01:46Z pe $

EBAS Masterdata Class for parameter masterdata

This module implements the class EbasMasterPM.

History:
V.1.0.0  2014-10-06  pe  initial version

"""

from .offline_masterdata import PMOfflineMasterData
from .base import EbasMasterBase
from .sc import EbasMasterSC

def _list_matrix_group(PM_META, regime, group, comp_name):
    """
    list all matrices within the group for which the regime and component
    are defined.
    This is used for mangling different unit on export conversions.
    See _exceptions_unit_exp above and
    ebas/domain/basic_domain_logic/unit_convert.py

    This method is needed on module level (for _exceptions_unit_exp) and as
    class methoid within EbasMasterPM. Implement here, use it in the class
    method.
    """
    groups = {
        'ALL_AEROSOL': (
            'pm1', 'pm1_humidified', 'pm1_non_refractory',
            'pm25', 'pm25_humidified', 'pm25_volatile', 'pm25_non_volatile',
            'pm10', 'pm10_humidified', 'pm10_volatile', 'pm10_non_volatile',
            'pm10_pm1', 'pm10_pm25',
            'pm_eq25', 'pm_eq35', 'pm_eq50', 'pm_eq75')}
    mats = [x[1] for x in PM_META.keys()
            if x[0] == regime and x[2] == comp_name and
                x[1] in groups[group]]
    return mats


class _ProtoEbasMasterPM(EbasMasterBase, PMOfflineMasterData):
    """
    Helper class, just to get the initialisation of the class right...
    Especially the initialisation og the class member PM_EXCEPTIONALUNIT_EXP
    as it depends on anouther class member (META) which is initialized in
    read_pickle_file()
    We could use a metaclass for this (as well as for reading from the pickle
    file in PMOfflineMasterData)?
    Think this easier concept is better...
    """
    @classmethod
    def _exceptions(cls):
        """
        Generate dictionary for exceptions (special datalevels, not imported but
        should be just file format checked.
        Parameters:
            None
        Returns:
            exception dict
        """
        exceptions = {'0': {}, '1': {}}
    
        # ACSM lev0:
        exceptions['0'][('IMG', 'pm1_non_refractory', 'collection_efficiency')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'pm1_non_refractory',
                    'CO_COMP_NAME': 'collection_efficiency',
                    'PM_UNIT': 'no unit',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        exceptions['0'][('IMG', 'pm1_non_refractory',
                         'nitrogen_ion_flow_signal')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'pm1_non_refractory',
                    'CO_COMP_NAME': 'nitrogen_ion_flow_signal',
                    'PM_UNIT': 'A',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        # TODO: nitrogen_ion_flow_signal or airbeam_signal? I think it's the same...
        exceptions['0'][('IMG', 'instrument',
                         'airbeam_signal')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'airbeam_signal',
                    'PM_UNIT': 'A',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        exceptions['0'][('IMG', 'instrument',
                         'frequency')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'frequency',
                    'PM_UNIT': 'Hz',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        exceptions['0'][('IMG', 'instrument',
                         'electric_power')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'electric_power',
                    'PM_UNIT': 'W',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        exceptions['0'][('IMG', 'pm1_non_refractory',
                         'ionization_efficiency')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'ionization_efficiency',
                    'PM_UNIT': 'A/ug/m3',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        exceptions['0'][('IMG', 'pm1_non_refractory',
                         'relative_ionization_efficiency')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'pm1_non_refractory',
                    'CO_COMP_NAME': 'relative_ionization_efficiency',
                    'PM_UNIT': 'no unit',
                    'PM_CFNAME': None,
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                }
        # NOX lev 0
        basedict = {
            'RE_REGIME_CODE': 'IMG',
            'MA_MATRIX_NAME': 'air',
            'PM_CFNAME': None,
            'PM_CFUNIT': None,
            'PM_REMARKS': None,
        }
        for comb in (('NO_#counts', 'cps'),
                     ('NO_converter_#counts', 'cps'),
                     ('NO_sensitivity', '(pmol/mol)/cps'),
                     ('converter_efficiency', '%'),
                     ):
            dict_ = basedict.copy()
            dict_.update({'CO_COMP_NAME': comb[0], 'PM_UNIT': comb[1]})
            exceptions['0'][(dict_['RE_REGIME_CODE'], dict_['MA_MATRIX_NAME'],
                             dict_['CO_COMP_NAME'])] = dict_
    
        # xMPS lev0:
        basedict = {
            'RE_REGIME_CODE': 'IMG',
            'PM_CFNAME': None,
            'PM_CFUNIT': None,
            'PM_REMARKS': None,
        }
        for comb in (('flow_rate', 'l/min', ('instrument',)),
                     ('status', 'no_unit', ('instrument',)),
                     ('particle_number_concentration', '1/cm3',
                         ('pm1', 'pm10', 'aerosol',)),
                     ('particle_diameter', 'um', ('pm1', 'pm10', 'aerosol',)),
                     ):
            for matrix in comb[2]:
                dict_ = basedict.copy()
                dict_.update({'CO_COMP_NAME': comb[0], 'PM_UNIT': comb[1],
                              'MA_MATRIX_NAME': matrix})
                exceptions['0'][(dict_['RE_REGIME_CODE'], dict_['MA_MATRIX_NAME'],
                                 dict_['CO_COMP_NAME'])] = dict_
    
        # filter_absorption_photometer lev0:
        basedict = {
            'RE_REGIME_CODE': 'IMG',
            'PM_CFNAME': None,
            'PM_CFUNIT': None,
            'PM_REMARKS': None,
        }
        for comb in (('equivalent_black_carbon_loading', 'ug',
                          ('pm1', 'pm10', 'pm25', 'aerosol',)),
                     ('biomass_burning_aerosol_fraction', '%',
                          ('pm1', 'pm10', 'pm25', 'aerosol',)),
                     ('filter_loading_compensation_parameter', 'no unit',
                          ('pm1', 'pm10', 'pm25', 'aerosol',)),
                     ('reference_beam_signal', 'no unit',
                          ('pm1', 'pm10', 'pm25', 'aerosol',)),
                     ('sensing_beam_signal', 'no unit',
                          ('pm1', 'pm10', 'pm25', 'aerosol',)),
                     ('sample_length_on_filter', 'm', ('instrument',)),
                     ('filter_number', 'no unit', ('instrument',)),
                     ):
            for matrix in comb[2]:
                dict_ = basedict.copy()
                dict_.update({'CO_COMP_NAME': comb[0], 'PM_UNIT': comb[1],
                              'MA_MATRIX_NAME': matrix})
                exceptions['0'][(dict_['RE_REGIME_CODE'], dict_['MA_MATRIX_NAME'],
                                 dict_['CO_COMP_NAME'])] = dict_
        # CCNC lev0:
        exceptions['0'][('IMG', 'instrument', 'supersaturation')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'supersaturation',
                    'PM_UNIT': '%',
                    'PM_CFNAME': None,
                    'PM_REMARKS': None,
                }
        exceptions['0'][('IMG', 'instrument', 'temperature_gradient')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'temperature_gradient',
                    'PM_UNIT': 'K',
                    'PM_CFNAME': None,
                    'PM_REMARKS': None,
                }
    
        # CCNC lev1:
        exceptions['1'][('IMG', 'instrument', 'supersaturation')] = {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'instrument',
                    'CO_COMP_NAME': 'supersaturation',
                    'PM_UNIT': '%',
                    'PM_CFNAME': None,
                    'PM_REMARKS': None,
                }
        # cpc lev0:
        basedict = {
            'RE_REGIME_CODE': 'IMG',
            'PM_CFNAME': None,
            'PM_CFUNIT': None,
            'PM_REMARKS': None,
        }
        for comb in (('flow_rate', 'l/min', ('instrument',)),
                     ('pulse_width', 'us', ('instrument',)),):
            for matrix in comb[2]:
                dict_ = basedict.copy()
                dict_.update({'CO_COMP_NAME': comb[0], 'PM_UNIT': comb[1],
                              'MA_MATRIX_NAME': matrix})
                exceptions['0'][(dict_['RE_REGIME_CODE'], dict_['MA_MATRIX_NAME'],
                                 dict_['CO_COMP_NAME'])] = dict_
    
        # nephelometer lev0
        basedict = {
            'RE_REGIME_CODE': 'IMG',
            'PM_CFNAME': None,
            'PM_CFUNIT': None,
            'PM_REMARKS': None,
        }
        for comb in (
            ('aerosol_light_scattering_coefficient_zero_measurement', '1/Mm',
             ('pm1', 'pm10', 'aerosol',)),
            ('aerosol_light_backscattering_coefficient_zero_measurement', '1/Mm',
             ('pm1', 'pm10', 'aerosol',)),
            ('aerosol_light_rayleighscattering_coefficient_zero_measurement', '1/Mm',
             ('pm1', 'pm10', 'aerosol',)),
           ):
            for matrix in comb[2]:
                dict_ = basedict.copy()
                dict_.update({'CO_COMP_NAME': comb[0], 'PM_UNIT': comb[1],
                              'MA_MATRIX_NAME': matrix})
                exceptions['0'][(dict_['RE_REGIME_CODE'], dict_['MA_MATRIX_NAME'],
                                 dict_['CO_COMP_NAME'])] = dict_
    
        cls.PM_EXCEPTIONAL = exceptions
    
    @classmethod
    def _exceptions_unit_exp(cls):
        """
        Generate dictionary of exceptions for unit conversions.
        We need one exception for each output conversion we do in 
        ebas.domain.basic_domain_logic.unit_convert.output_conv_params()
        
        Parameters:
            None
        Returns:
            exception dict
    
        IMPORTANT: Beacuse some exceptions use the META dict, this method
        needs to be re-run, when EbasMasterPM.META is changed
        e.g. after from_db
        """
        exceptions = {
            ('IMG', 'air', 'nitrogen_monoxide', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'nitrogen_monoxide',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_nitrogen_monoxide_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'nitrogen_dioxide', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'nitrogen_dioxide',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_nitrogen_dioxide_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'NOx', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'NOx',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_nox_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'sulphur_dioxide', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'sulphur_dioxide',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_sulfur_dioxide_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'ozone', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'ozone',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_ozone_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'ethanal', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'ethanal',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_ethanal_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'ethanol', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'ethanol',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_ethanol_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'methanal', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'methanal',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_methanal_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'propanone', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'propanone',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_propanone_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'propanal', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'propanal',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_propanal_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'n-propanol', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'n-propanol',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_n-propanol_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', '2-methyl-2-propenal', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': '2-methyl-2-propenal',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_2-methyl-2-propenal_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'ethanedial', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'ethanedial',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_ethanedial_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', '2-oxopropanal', 'nmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': '2-oxopropanal',
                    'PM_UNIT': 'nmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_2-oxopropanal_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'tetrachloroethylene', 'pmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'tetrachloroethylene',
                    'PM_UNIT': 'pmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_tetrachloroethylene_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', '2-propenal', 'pmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': '2-propenal',
                    'PM_UNIT': 'pmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_2-propenal_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', '3-buten-2-one', 'pmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': '3-buten-2-one',
                    'PM_UNIT': 'pmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_3-buten-2-one_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            ('IMG', 'air', 'butanone', 'pmol/mol'):
                {
                    'RE_REGIME_CODE': 'IMG',
                    'MA_MATRIX_NAME': 'air',
                    'CO_COMP_NAME': 'butanone',
                    'PM_UNIT': 'pmol/mol',
                    'PM_CFNAME': 'mole_fraction_of_butanone_in_air',
                    'PM_CFUNIT': None,
                    'PM_REMARKS': None,
                },
            }
    
        # Special case: parameters which are converted on output to a different unit
        # but the CF_NAME is the same. E.g. nitrate ("ug N/m3" -> "ug/m3"
    
        # all nitrogen aerosols: nitrate, ammonium
        # here we duplicate all entries with *any* aerosol matrix and insert it
        # with an alternative unit.
        # IMPORTANT: this needs to be repeated, when EbasMasterPM.META is changed
        # e.g. after from_db
        for comp in ('nitrate', 'ammonium'):
            for mat in _list_matrix_group(cls.META, 'IMG', "ALL_AEROSOL", comp):
                    dic = cls.META[('IMG', mat, comp)].copy()
                    if dic['PM_UNIT'] != 'ug N/m3':
                        RuntimeError('export unit exceptions setup error')
                    dic['PM_UNIT'] = 'ug/m3'
                    # add the same metadata, but with a different unit:
                    exceptions[('IMG', mat, comp, 'ug/m3')] = dic
        # all sulphour aerosols: sulphate_total
        # here we duplicate all entries with *any* aerosol matrix and insert it
        # with an alternative unit.
        # IMPORTANT: this needs to be repeated, when EbasMasterPM.META is changed
        # e.g. after from_db
        for comp in ('sulphate_total', ):
            for mat in _list_matrix_group(cls.META, 'IMG', "ALL_AEROSOL", comp):
                dic = cls.META[('IMG', mat, comp)].copy()
                if dic['PM_UNIT'] != 'ug S/m3':
                    RuntimeError('export unit exceptions setup error')
                dic['PM_UNIT'] = 'ug/m3'
                # add the same metadata, but with a different unit:
                exceptions[('IMG', mat, comp, 'ug/m3')] = dic
        cls.PM_EXCEPTIONALUNIT_EXP = exceptions


class EbasMasterPM(_ProtoEbasMasterPM):
    """
    Domain Class for Parameter masterdata.
    Objects of this class do not represent entities, this class provides class
    methods for handling parameter and checking them against master data.
    Parameter master data are retrieved from database or from offline storage
    when no database access is possible.
    """
    # read offline masterdata for PM (parameters)
    # Those are fallback values, will be read from database as soon as possible.
    _ProtoEbasMasterPM.read_pickle_file()
    # some hardcoded exceptional parameters (see method exceptional):
    _ProtoEbasMasterPM._exceptions()
    _ProtoEbasMasterPM._exceptions_unit_exp()

    def __init__(self, dbh=None):
        """
        Read pm masterdata if dbh is provided.
        """
        PMOfflineMasterData.__init__(self)
        self.sc_ = EbasMasterSC(dbh=dbh)
        if not self.__class__.INIT and dbh:
            self.from_db(dbh)
            # this changes the META dict. _exceptions_unit_exp MUST be re-run
            # (beacuse some exceptions build on existing definitions
            # (e.g. nitrate)
            self._exceptions_unit_exp()

    def __getitem__(self, key):
        """
        Exception for PM: some attributes will be overruled by statistics code!
        Parameters:
            key    (regime, matrix, component, statistics)
                   Only the first 3 are used for PM lookup!
                   Statistics is used in case of overrules
        """
        return self._override_sc(self.__class__.META[key[:3]], key[3])

    def _override_sc(self, pm_, statistics):
        """
        Handle the unit, cfname and cfunit overeride for statistic codes
        (e.g. sample count).
        Parameters:
            pm_          pm element which would be returnd by default
            statistics   statstics code
        Returns:
            modified pm_
        """
        sc_ = self.sc_[statistics]
        if sc_.SC_UNIT is not None or sc_.SC_CFNAME is not None or \
                sc_.SC_CFUNIT is not None:
            ret = pm_.copy()
            if sc_.SC_UNIT is not None:
                ret.PM_UNIT = sc_.SC_UNIT
            if sc_.SC_CFNAME is not None:
                ret.PM_CFNAME = sc_.SC_CFNAME
            if sc_.SC_CFUNIT is not None:
                ret.PM_CFUNIT = sc_.SC_CFUNIT
            return ret
        return pm_

    def exceptional(self, data_level, key_tupel):
        """
        Find exceptional parameters (depend on data_level).
        Those parameters are NOT defined in the database, but might be e.g. used
        in lev 0 files.
        Thus they are accepted when reading the file, but the domain layer will
        issue an error message.
        """
        if data_level in ('0a', '0b'):
            data_level = '0'
        return self._override_sc(
            self.__class__.PM_EXCEPTIONAL[data_level][key_tupel[:3]],
            key_tupel[3])

    def exceptional_unit_exp(self, key_tupel):
        """
        Find exceptional parameters (with exceptional units).
        This is only relevant for export of variables which were converted to
        alternative units (e.g. ozone, VOCs etc).
        Those parameters are defined in the database with DIFFERENT UNITS, so
        the usual lookup fot the tuple (regime, matrix, comp) will give a
        WRONG CF standard name!
        Parameters:
            key_tupel  (regime, matrix, component, unit)
        """
        return self.__class__.PM_EXCEPTIONALUNIT_EXP[key_tupel]

    @classmethod
    def exist_unit(cls, unit):
        """
        Check if the unit exists (regardless of PM (RE, MA, CO)).
        Parameters:
            unit    unit to be checked
        Returns:
            True/False
        """
        if any([elem['PM_UNIT'] == unit for elem in list(cls.META.values())]):
            return True
        return False

    @classmethod
    def exist_unit_exceptional(cls, datalevel, unit):
        """
        Check if the unit exists (regardless of PM (RE, MA, CO)).
        Parameters:
            unit    unit to be checked
        Returns:
            True/False
        """
        if datalevel in ('0a', '0b'):
            datalevel = '0'
        if datalevel not in cls.PM_EXCEPTIONAL:
            return False
        if any([elem['PM_UNIT'] == unit
                for elem in list(cls.PM_EXCEPTIONAL[datalevel].values())]):
            return True
        return False

    @classmethod
    def list_matrix_group(cls, regime, group, comp_name):
        """
        list all matrices within the group for which the regime and component
        are defined.
        This is used for mangling different unit on export conversions.
        See _exceptions_unit_exp above and
        ebas/domain/basic_domain_logic/unit_convert.py
        """
        return _list_matrix_group(cls.META, regime, group, comp_name)

