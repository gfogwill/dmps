"""
$Id: postgres.py 2599 2021-01-27 16:27:04Z pe $

Helper module fro accessing PostgreSQL databases.

# Synopsis:

## Build an application db access class

Advantage: convert strings to unicode, log executes as debug, make use of
           _convert_row2dict and _convert_rows2dictlist

```python
class MyDbAccess(PostgresDbBase):
    def seltestdata(self):
        curs = self.conn.cursor()
        curs.execute('select * from test')
        return self._convert_rows2dictlist(curs.fetchall(), curs.description)

...

db = MyDbAccess(host=host, user=user, password=password, dbname=dbname)
print db.seltestdata()
print db.seltestdata()[1].columnname
```

## Use customized classes w/o creating a dedicated db layer class:

e.g. for small scripts.
Advantage: convert strings to unicode, log executes as debug.

```python
import databases.postgres
import psycopg2

con = psycopg2.connect(
    host=None, user='paul', password=None, dbname='paul',
    connection_factory=databases.postgres.PostgresDbConnection,
    cursor_factory=databases.postgres.PostgresDbCursor)
curs = con.cursor()
curs.execute('select * from test')
print list(curs.fetchall())
```
"""

import logging
import psycopg2
import six
import uuid
from textwrap import dedent
from nilutility.datatypes import DataObject
from .base import DbBase

# make sure strings are converted form database character set to unicode
# in python2 (in python3 it's default)
psycopg2.extensions.register_type(psycopg2.extensions.UNICODE)
psycopg2.extensions.register_type(psycopg2.extensions.UNICODEARRAY)


class PostgresDbBase(DbBase):
    """
    Base class for application database layer classes (should be derived from
    this class).
    """

    # Used by base class
    DB_MAXLEN_IDENTIFIER = 63

    def __init__(self, dsn=None, connection_factory=None, cursor_factory=None,
                 async_=False, **kwargs):
        """
        Initialize DB connection. Open DB.
        Parameters:
            all parameters accepted by psycopg2.connect
            most prominent:
                dbname, user, password, host, port
        Returns:
            None
        Additional parameters can be either suplied by keyword parameters or a
        dsn connection sting. See:
        https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-CONNSTRING
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.conn = None
        self.cursor_fetch_buffer = 1000
        self._connect(dsn, connection_factory, cursor_factory, async_, **kwargs)
        self.tmp_addsql_crit_tables = []

    def _connect(self, dsn=None, connection_factory=None, cursor_factory=None,
                 async_=False, **kwargs):
        """
        Connect the database.
        Parameters:
            all parameters accepted by psycopg2.connect
        Returns:
            None
        Additional parameters can be either suplied by keyword parameters or a
        dsn connection sting. See:
        https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-CONNSTRING
        """
        if connection_factory is None:
            connection_factory = PostgresDbConnection
        if cursor_factory is None:
            cursor_factory = PostgresDbCursor
        self.conn = psycopg2.connect(dsn=dsn, connection_factory=connection_factory, cursor_factory=cursor_factory,    
                                     async_=async_, **kwargs)
        self.logger.info('connected database %s',
                         self.conn.get_dsn_parameters())

    def close(self):
        """
        Close the db connection, cleanup.
        """
        self.conn.close()

    def commit(self):
        """
        Commit changes in the connection.
        """
        # Make sure the temporary entries in TMP_ADDSQL_CRIT are never committed
        self._cleanup_addsql_crit()  # just in case...
        self.conn.commit()

    def rollback(self):
        """
        Rollback changes in the connection.
        """
        self.conn.rollback()

    def _execute(self, query, vars=None):
        """
        Provides an execute method for the object (private, only to be used
        internally by derived object's access methods).
        Open a new cursor, execute and return the cursor.
        Includes logging through the customized PostgresDbCursor object.
        Parmeter:
            query    the sql query
            vars     variables for the query
        Returns:
            cursor object
        """
        curs = self.conn.cursor()
        curs.execute(query, vars)
        return curs

    def _executemany(self, query, vars_list):
        """
        Provides an executemany method for the object (private, only to be used
        internally by derived object's access methods).
        Open a new cursor and executemany on it.
        Includes logging through the customized PostgresDbCursor object.
        Parmeter:
            query      the sql query
            vars_list  list of variables for the query
        Returns:
            None
        """
        curs = self.conn.cursor()
        curs.executemany(query, vars_list)

    def _yield_dict(self, curs):
        """
        Yields the cursur results as dictionary per row.

        Parameters:
            curs    opened cursor object
        Returns:
            generator, dictionaries with results, None if no result
        """
        while True:
            results = curs.fetchmany(self.cursor_fetch_buffer)
            if not results:
                curs.close()
                break
            for result in results:
                yield self._convert_row2dict(result, curs.description)

    @staticmethod
    def _convert_row2dict(result, desc):
        """
        Converts a fetched row (tupel) to a dictionary (keys=colnames).

        Parameters:
            result    fetched result row (tupel)
            desc      cursor description
        """
        ret = DataObject()
        for i, item in enumerate(result):
            colnam = desc[i][0]
            ret[colnam] = item
        return ret

    @classmethod
    def _convert_rows2dictlist(cls, resultlist, desc):
        """
        Converts a fetched row (tupel) to a dictionary (keys=colnames).

        Parameters:
            resultlist  fetched result rows (list of tupel)
            desc        cursor description
        """
        ret = []
        for row in resultlist:
            ret.append(cls._convert_row2dict(row, desc))
        return ret

    @staticmethod
    def _hostvar_sql(varname):
        """
        Returns the sql part of a host variable name.
        """
        return "%({})s".format(varname)

    @staticmethod
    def _hostvar_param(varname):
        """
        Returns the parameter dictionary key for a host variable.
        """
        return varname

    def _insert_addsql_crit(self, in_list):
        """
        Insert table entries for addsql_crit.
        Parameters:
            in_list    list of criteria values
        Returns:
            temp_id    id for the values in the temp table
        """
        if any([isinstance(elem[1], six.string_types) for elem in in_list]):
            valtype = 'VAL_CHR'
        elif any([isinstance(elem[1], float) for elem in in_list]):
            valtype = 'VAL_DBL'
        else:
            valtype = 'VAL_INT'
        temp_sql = dedent("""\
             insert into TMP_ADDSQL_CRIT (ID, TIME, {})
                 values (%(ID)s, current_timestamp AT TIME ZONE 'UTC',
                 %(VAL)s)""".format(valtype))
        temp_id = uuid.uuid1().hex
        self.tmp_addsql_crit_tables.append(temp_id)
        temp_params = {'ID': temp_id}
        for elem in in_list:
            temp_params['VAL'] = elem[1]
            self._execute(temp_sql, temp_params)
        return "select {} from TMP_ADDSQL_CRIT where ID='{}'".format(
            valtype, temp_id)

    def _cleanup_addsql_crit(self):
        """
        Cleanup temp table entries from addsql_crit
        Parameters:
            None
        Returns:
            None
        """
        sql = "delete from TMP_ADDSQL_CRIT where ID=%(ID)s"
        params = {}
        for id_ in self.tmp_addsql_crit_tables:
            params['ID'] = id_
            self._execute(sql, params)
        self.tmp_addsql_crit_tables = []

class PostgresDbConnection(psycopg2.extensions.connection):
    # pylint: disable=R0903
    # R0903: Too few public methods
    """
    Derived class for a postgeres connection object.
    """
    pass
    

class PostgresDbCursor(psycopg2.extensions.cursor):  # pylint: disable=R0903
    # R0903: Too few public methods
    """
    Logging cursor object. Logs every execute with severity debug, logs
    exceptions as error.
    """
    def execute(self, query, vars=None):
        """
        Log execute with severity debug, log exceptions as error.
        Parameters
        """
        logger = logging.getLogger('PostgresDb')
        logger.debug(u'execute: %s', self.mogrify(query, vars))
        try:
            psycopg2.extensions.cursor.execute(self, query, vars)
        except Exception as exc:
            logger.error("%s: %s", exc.__class__.__name__, exc)
            raise

    def executemany(self, query, vars_list):
        """
        Log executemany with severity debug, log exceptions as error.
        Parameters
        TODO: consider changing to the faster method using (execute-prepare,
              execute_batch, execute-deallocate), as described at:
              https://www.psycopg.org/docs/extras.html#fast-exec
        """
        logger = logging.getLogger('PostgresDb')
        logger.debug('executemany: %s', query)
        for i, vars in enumerate(vars_list):
            if isinstance(vars, dict):
                logger.debug('executemany vars: ' + ', '.join(
                    ['{0}: {1} ({2})'.format(key, value, type(value))     
                     for (key, value) in list(vars.items())]))
            else:
                logger.debug('executemany vars: {}'.format(vars))
        try:
            psycopg2.extensions.cursor.executemany(self, query, vars_list)
        except Exception as exc:
            logger.error("%s: %s", exc.__class__.__name__, exc)
            raise


class PostgresDb(PostgresDbBase):
    """
    Final class for database access in Postgres. Using mainly the execute method
    (client needs to formulate the sql).
    This class is meant to be used for more ad-hoq dataabase queries. Derived
    classes which aim to provide a set of customized db access methods for an
    application, should be derived from PostgresDbBase instead of this class.
    See e.g. ebas/db4 for amore advanced final implementation.
    """

    def execute(self, *args, **kwargs):
        """
        Wrapper method to expose base classes _execute as public.
        See PostgresDbBase._execute

        Open a new cursor, execute and return the cursor.
        Includes logging through the customized PostgresDbCursor object.
        Parmeter:
            query    the sql query
            vars     variables for the query
        Returns:
            cursor object
        """
        return self._execute(*args, **kwargs)

    def executemany(self, *args, **kwargs):
        """
        Wrapper method to expose base classes _executemany as public.
        See PostgresDbBase._executemanty
        Open a new cursor and executemany on it.
        Includes logging through the customized PostgresDbCursor object.
        Parmeter:
            query      the sql query
            vars_list  list of variables for the query
        Returns:
            None
        """
        self._executemany(*args, **kwargs)

