"""
$Id: electric.py 2660 2021-06-02 10:00:04Z pe $

atmos_phys unit conversion routines for gasses.
"""

from nilutility.datatypes import DataObject
from .base import ConvertBaseFactor


class ConvertElectricCurrent(ConvertBaseFactor):
    """
    Conversion class for NOx (NO, NO2, NOx) conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        """
        factors = {
            ('mA', 'A'): 0.001,
            ('A', 'mA'): 1000.0,
        }

        if self.from_unit not in \
               ('A', 'mA') or \
           self.to_unit not in \
               ('A', 'mA') or \
           self.from_unit == self.to_unit:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))

        self.parameters = DataObject(
            factor=factors[(self.from_unit, self.to_unit)])

