"""
ebas/domain/masterdata
$Id: __init__.py 2502 2020-10-14 16:57:35Z pe $

EBAS domain layer (domain logic masterdata)

History:
V.1.0.0  2014-04-10  pe  initial version

"""
from .am import EbasMasterAM
from .ac import EbasMasterAC
from .ay import EbasMasterAY
from .bc import EbasMasterBC
from .cc import EbasMasterCC
from .co import EbasMasterCO
from .dc import DCBase
from .fl import EbasMasterFL
from .fm import EbasMasterFM
from .ft import EbasMasterFT
from .im import EbasMasterIM
from .org import EbasMasterOR
from .pm import EbasMasterPM
from .pr import EbasMasterPR
from .qm_qv import EbasMasterQM, EbasMasterQV
from .sp import EbasMasterSP
from .st import EbasMasterST
from .zn import EbasMasterZN
from .zt import EbasMasterZT


def read_all_caches_from_db(dbh):
    """
    Reads all chache masterdata from db. This can be called by programs that
    have db access and want to make sure all called modules work with current
    master data from the database.
    Parameters:
        dbh    database handle
    Returns:
        None
    """
    EbasMasterAC(dbh)
    EbasMasterAM(dbh)
    EbasMasterAY(dbh)
    EbasMasterBC(dbh)
    EbasMasterCC(dbh)
    EbasMasterCO(dbh)
    DCBase(dbh)
    EbasMasterFL(dbh)
    EbasMasterFM(dbh)
    EbasMasterFT(dbh)
    EbasMasterIM(dbh)
    EbasMasterOR(dbh)
    EbasMasterPM(dbh)
    EbasMasterPR(dbh)
    EbasMasterQM(dbh)
    EbasMasterQV(dbh)
    EbasMasterSP(dbh)
    EbasMasterST(dbh)
    EbasMasterZN(dbh)
    EbasMasterZT(dbh)
