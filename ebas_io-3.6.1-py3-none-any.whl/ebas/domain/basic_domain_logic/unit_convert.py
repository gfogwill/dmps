"""
Unit conversion for ebas input and output
"""

import re
from atmos_phys.convert.gas import ConvertNOx, ConvertSulphurDioxide, \
    ConvertOzone, \
    ConvertEthanal, ConvertEthanol, ConvertMethanal, ConvertPropanone, \
    ConvertPropanal, ConvertNPropanol, Convert2Methyl2Propenal, \
    ConvertEthanedial, Convert2Oxopropanal, Convert2Propenal, \
    Convert3Buten2One, ConvertButanone
from atmos_phys.convert.aerosol import ConvertNitrate, ConvertAmmonium, \
    ConvertSulphate
from atmos_phys.convert.temperature import ConvertTemperature
from atmos_phys.convert.pressure import ConvertPressure
from atmos_phys.convert.electric import ConvertElectricCurrent
from ebas.domain.masterdata.pm import EbasMasterPM


class NoConversion(Exception):
    """
    Exception raised when no conversion is possible.
    """
    pass

class UnitConvert(object):
    """
    Unit conversion for ebas input and output
    """

    # Configuration for EBAS unit conversion on import/export
    # regime, matrix, comp_name (and ebas_unit on export) identify the parameter
    # import: import conversion should be done
    #     units: accepted units for conversion on import
    #     need_stdcond: True: only converted if std conditions are given
    #                         (no conversion if not given in metadata)
    #                   False: not needed, conversion is possible anyway
    #     use_stdcond: standard conditions to be used for import conversion
    #                  (pressuer hPa, temp K) or (None, None) (no std cond used)
    #                  if need_stdcond: this is overruled
    #     set_stdcond: std condistions will be set to after conversion
    #                  (pressuer hPa, temp K)
    #                  (None, None) set to none
    #                  None: do not change
    #     roundoffset: round offset used for import conversion
    # export: export conversion should be done
    #     unit: unit to be converted on export
    #     need_stdcond: True: only converted if std conditions are given
    #                         (no conversion if not given in metadata)
    #                   False: not needed, conversion is possible anyway
    #     use_stdcond: standard conditions to be used for export conversion
    #                  (pressuer hPa, temp K) or (None, None) (no std cond used)
    #                  if need_stdcond: this is overruled
    #     set_stdcond: std condistions will be set to after export conversion
    #                  (pressuer hPa, temp K)
    #                  (None, None) set to none
    #                  None: do not change
    #     roundoffset: round offset used for export conversion
    #     maxround: maxround used for export conversion
    # cvt_class: conversion class to be used
    CONVERSIONS = [
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "nitrogen_monoxide",
            "ebas_unit": "ug N/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertNOx
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "nitrogen_dioxide",
            "ebas_unit": "ug N/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertNOx
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "NOx",
            "ebas_unit": "ug N/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertNOx
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "sulphur_dioxide",
            "ebas_unit": "ug S/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertSulphurDioxide
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "ozone",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 293.15),
                "set_stdcond": (1013.25, 293.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertOzone
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "ethanal",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertEthanal
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "ethanol",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertEthanol
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "methanal",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertMethanal
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "propanone",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertPropanone
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "propanal",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertPropanal
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "n-propanol",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertNPropanol
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "2-methyl-2-propenal",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": Convert2Methyl2Propenal
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "ethanedial",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertEthanedial
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "2-oxopropanal",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "nmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": Convert2Oxopropanal
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "2-propenal",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "pmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": Convert2Propenal
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "3-buten-2-one",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "pmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": Convert3Buten2One
        },
        {
            "regime": "IMG",
            "matrix": "air",
            "comp_name": "butanone",
            "ebas_unit": "ug/m3",
            "import": {
                "units": ['nmol/mol', 'ppbv', 'ppb', 'pmol/mol', 'pptv', 'ppt'],
                "need_stdcond": False,
                "use_stdcond": (1013.25, 273.15),
                "set_stdcond": (1013.25, 273.15),
                "roundoffset": 1,
            },
            "export": {
                "unit": "pmol/mol",
                "need_stdcond": True,
                "use_stdcond": (None, None),
                "set_stdcond": (None, None),
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertButanone
        },

        {
            "regime": "IMG",
            "matrix": "ALL_AEROSOL",
            "comp_name": "nitrate",
            "ebas_unit": "ug N/m3",
            "import": {
                "units": ['ug/m3'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                "roundoffset": 1,
            },
            "export": {
                "unit": "ug/m3",
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertNitrate
        },

        {
            "regime": "IMG",
            "matrix": "ALL_AEROSOL",
            "comp_name": "ammonium",
            "ebas_unit": "ug N/m3",
            "import": {
                "units": ['ug/m3'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                "roundoffset": 1,
            },
            "export": {
                "unit": "ug/m3",
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertAmmonium
        },

        {
            "regime": "IMG",
            "matrix": "ALL_AEROSOL",
            "comp_name": "sulphate_total",
            "ebas_unit": "ug S/m3",
            "import": {
                "units": ['ug/m3'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                "roundoffset": 1,
            },
            "export": {
                "unit": "ug/m3",
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                "roundoffset": -1,
                "maxround": 0,
            },
            "cvt_class": ConvertSulphate
        },

        {
            "regime": "IMG",
            "matrix": "met",
            "comp_name": "temperature",
            "ebas_unit": "deg C",
            "import": {
                "units": ['K'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                # no roundoffset and maxround, conversion is just an addition
            },
            # no export conversion
            "cvt_class": ConvertTemperature
        },
        {
            "regime": "IMG",
            "matrix": "instrument",
            "comp_name": "temperature",
            "ebas_unit": "K",
            "import": {
                "units": ['deg C'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                # no roundoffset and maxround, conversion is just an addition
            },
            # no export conversion
            "cvt_class": ConvertTemperature
        },
        {
            "regime": "IMG",
            "matrix": "instrument",
            "comp_name": "pressure",
            "ebas_unit": "hPa",
            "import": {
                "units": ['Torr'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                # no roundoffset and maxround, conversion is just an addition
            },
            # no export conversion
            "cvt_class": ConvertPressure
        },

        {
            "regime": "IMG",
            "matrix": "instrument",
            "comp_name": "electric_current",
            "ebas_unit": "A",
            "import": {
                "units": ['mA'],
                "need_stdcond": False,
                "use_stdcond": (None, None),
                "set_stdcond": None,
                # no roundoffset and maxround, conversion is just an addition
            },
            # no export conversion
            "cvt_class": ConvertElectricCurrent
        }
    ]

    CONVERSIONS_CHECKED = False

    def __init__(self):
        """
        Set up the object.
        Parameters:
            None
        Returns:
            None
        """
        self._check_conversions()

    @classmethod
    def converted_units(cls):
        """
        List all units which could be converted on import.
        This method is used for checking valid units in ebas.io
        """
        converted_units = []
        for cvt in cls.CONVERSIONS:
            if 'import' in cvt:
                converted_units += cvt['import']['units']
        return converted_units

    def _check_conversions(self):
        """
        Sanity checks for the CONVERSIONS configuration.
         - Check if parameter exists
         - Check if ebas_unit is correct
         - Check if conversion class name is correct
         - Check if masterdata.pm has exceptional masterdata for the converted
           unit on export: If not checked here, an exception will only be raised
           when the conversion in question is actually used on an export. Thus
           bugs might be hidden for a long time and then crash the export
           process at inconvenient times.
        Here we precheck if the masterdata are in place, raising an exception
        even if the conversion is not nedded now.
        Parametrs:
            None
        Returns:
            None
        Raises:
            KeyError if masterdata are not found
            RuntimeError if ebas_unit is not found
        """

        def generic_cvt_name(comp):
            """
            Generate a generic class name for conversion objects.
            Generic class names are 'Convert' + camel case on - and _
            Parameters:
                component name
            Returns:
                the generic name for a conversion name (convention)
            """
            parts = ('Convert ' + re.sub(r"(_|-)+", " ", comp)).split()
            return "".join([part[0].upper()+part[1:] for part in parts])

        if self.__class__.CONVERSIONS_CHECKED:
            return
        mpm = EbasMasterPM()

        # replace ALL_AEROSOL matrix with all defined matices:
        i = 0
        while i < len(self.__class__.CONVERSIONS):
            cvt = self.__class__.CONVERSIONS[i]
            if cvt['matrix'] == "ALL_AEROSOL":
                mats = mpm.list_matrix_group(cvt['regime'], cvt['matrix'],
                                             cvt['comp_name'])
                if not mats:
                    raise RuntimeError(
                        "No areosol parameters for conversion {}".format(cvt))
                for mat in mats:
                    new = cvt.copy()
                    new['matrix'] = mat
                    self.__class__.CONVERSIONS.append(new)
                del self.__class__.CONVERSIONS[i]
                # del element, do not incremet i
            else:
                i += 1

        for cvt in self.__class__.CONVERSIONS:
            # check existence of original parameter
            # (e.g. comp name renamed in ebas?)
            pm_ = mpm[(cvt['regime'], cvt['matrix'], cvt['comp_name'],
                       'arithmetic mean')]
            # raise KeyError if not extsts
            # (e.g. component renamed in the database)
            if pm_.PM_UNIT != cvt['ebas_unit']:
                raise RuntimeError("PM unit error ({})".format(cvt))

            # check class name for conversion class (avoid copy/paste errors,
            # make sure the class names are up to date when component names are
            # changed in ebas):
            if cvt['cvt_class'].__name__ != generic_cvt_name(cvt['comp_name']):
                if cvt['comp_name'] in \
                       ('nitrogen_monoxide', 'nitrogen_dioxide') and \
                   cvt['cvt_class'].__name__ == 'ConvertNOx':
                    pass  # exception OK
                elif cvt['comp_name'] in \
                       ('sulphate_total', ) and \
                   cvt['cvt_class'].__name__ == 'ConvertSulphate':
                    pass  # exception OK
                else:
                    raise RuntimeError(
                        "Unconventional conversion class name '{}' "
                        "(should be '{}'?)".format(
                            cvt['cvt_class'].__name__,
                            generic_cvt_name(cvt['comp_name'])))

            # check exceptional PM for converted unit on export:
            # raises KeyError if not exists
            if 'export' in cvt:
                mpm.exceptional_unit_exp(
                    (cvt['regime'], cvt['matrix'], cvt['comp_name'],
                     cvt['export']['unit']))
        self.__class__.CONVERSIONS_CHECKED = True

    def import_conv_params(self, regime, matrix,  # pylint: disable=R0913
                           comp_name, unit, std_pres, std_temp):
        # R0913: Too many arguments
        # --> acceptable here
        """
        Get input converison object.
        Parameters:
            regime       }
            matrix       } source parameter definition
            comp_name    }
            unit         }
            std_pres     standard pressure from metadata (None if not set)
            std_temp     standard temperature from metadata (None if not set)
        Returns:
            tupel (conv_obj, set_stdcond)
                Conversion object (from atmos_phys.convert, e.g. ConvertNOx,
                    ConvertOzone etc).
                set_stscond: (volume standard pressure,
                              volume standard temperature) to be set after
                             conversion
                             None if no change is needed
        Raises:
            NoConversion if no conversion possible
        """
        for cvt in self.__class__.CONVERSIONS:
            # loop through all defined coversions and choose if one is
            # applicable.
            # pylint: disable=R0916
            # R0916: Too many boolean expressions in if statement
            # --> not much to do about it?
            if 'import' in cvt and \
               cvt['regime'] == regime and \
               cvt['matrix'] == matrix and \
               cvt['comp_name'] == comp_name and \
               unit in cvt['import']['units'] and \
               (not cvt['import']['need_stdcond'] or \
                (std_pres is not None and std_temp is not None)):
                args = [unit, cvt['ebas_unit']]  # from_unit, to_unit
                kwargs = {}
                if "roundoffset" in cvt['import']:
                    kwargs["roundoffset"] = cvt['import']["roundoffset"]
                if "maxround" in cvt['import']:
                    kwargs["maxround"] = cvt['import']["maxround"]
                if cvt['import']['need_stdcond']:
                    kwargs["pressure"] = std_pres*100
                    kwargs["temperature"] = std_temp
                elif cvt['import']['use_stdcond']:
                    if cvt['import']['use_stdcond'][0] is not None:
                        kwargs["pressure"] = \
                            cvt['import']['use_stdcond'][0] * 100
                    if cvt['import']['use_stdcond'][1] is not None:
                        kwargs["temperature"] = cvt['import']['use_stdcond'][1]
                return (cvt['cvt_class'](*args, **kwargs),
                        cvt['import']['set_stdcond'])
        raise NoConversion

    def export_conv_params(self, regime, matrix,  # pylint: disable=R0913
                           comp_name, unit, std_pres, std_temp):
        # R0913: Too many arguments
        # --> acceptable here
        """
        Get output converison object.
        Parameters:
            regime       }
            matrix       } source parameter definition
            comp_name    }
            unit         }
            std_pres     standard pressure from metadata (None if not set)
            std_temp     standard temperature from metadata (None if not set)
        Returns:
            tupel (conv_obj, set_stdcond)
                Conversion object (from atmos_phys.convert, e.g. ConvertNOx,
                    ConvertOzone etc).
                set_stscond: (volume standard pressure,
                              volume standard temperature) to be set after
                             conversion
                             None if no change is needed
        Raises:
            NoConversion if no conversion possible
        """
        for cvt in self.__class__.CONVERSIONS:
            # loop through all defined coversions and choose if one is
            # applicable.
            # pylint: disable=R0916
            # R0916: Too many boolean expressions in if statement
            # --> not much to do about it?
            if 'export' in cvt and \
               cvt['regime'] == regime and \
               cvt['matrix'] == matrix and \
               cvt['comp_name'] == comp_name and \
               cvt['ebas_unit'] == unit and \
               (not cvt['export']['need_stdcond'] or \
                (std_pres is not None and std_temp is not None)):
                args = [unit, cvt['export']['unit']]  # from_unit, to_unit
                kwargs = {}
                if "roundoffset" in cvt['export']:
                    kwargs["roundoffset"] = cvt['export']["roundoffset"]
                if "maxround" in cvt['export']:
                    kwargs["maxround"] = cvt['export']["maxround"]
                if cvt['export']['need_stdcond']:
                    kwargs["pressure"] = std_pres*100
                    kwargs["temperature"] = std_temp
                elif cvt['export']['use_stdcond']:
                    if cvt['export']['use_stdcond'][0] is not None:
                        kwargs["pressure"] = \
                            cvt['export']['use_stdcond'][0] * 100
                    if cvt['export']['use_stdcond'][1] is not None:
                        kwargs["temperature"] = cvt['export']['use_stdcond'][1]
                return (cvt['cvt_class'](*args, **kwargs),
                        cvt['export']['set_stdcond'])
        raise NoConversion
